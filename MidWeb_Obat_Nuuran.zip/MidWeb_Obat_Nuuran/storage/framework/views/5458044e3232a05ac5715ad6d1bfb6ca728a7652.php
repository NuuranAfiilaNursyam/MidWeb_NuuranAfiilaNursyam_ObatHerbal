<style>
    body { 
background: linear-gradient(124deg, #ff2400, #e81d1d, #e8b71d, #e3e81d, #1de840, #1ddde8, #2b1de8, #dd00f3, #dd00f3);
background-size: 1800% 1800%;
background:color: 1800;

-webkit-animation: rainbow 18s ease infinite;
-z-animation: rainbow 18s ease infinite;
-o-animation: rainbow 18s ease infinite;
  animation: rainbow 18s ease infinite;}

@-webkit-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@-moz-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@-o-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@keyframes rainbow { 
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
  </style>
  <!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Obat - Obatan Herbal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <h2 class="text-center mt-2">Data Obat - Obatan Herbal</h2>
    <p class ="text-center mt-2" ><b><i>Created By Nuuran Afiila Nursyam_60900120040_Kelas B</i></b></p>
    <div class="container mt-3">
        
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Id Obat</th>
                    <th scope="col">Nama Obat</th>
                    <th scope="col">Bahan Obat</th>
                    <th scope="col">Khasiat Obat</th>
                    <th scope="col">Efek Samping</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Menu Pilihan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $obatHerbal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item->Obat); ?></td>
                        <td><?php echo e($item->Nama); ?></td>
                        <td><?php echo e($item->Bahan); ?></td>
                        <td><?php echo e($item->Khasiat); ?></td>
                        <td><?php echo e($item->Efek); ?></td>
                        <td><?php echo e($item->Harga); ?></td>
                        <td>
                            <a href="<?php echo e('/lihat/'.$item->id); ?>" class="btn btn-info">Lihat</a>
                            <a href="<?php echo e('/edit/'.$item->id); ?>" class="btn btn-success">Edit</a>
                            <a href="<?php echo e('/hapus/'.$item->id); ?>" onclick="return confirm('Yakin Untuk Menghapus?')"
                            class="btn btn-danger">Hapus</a>


                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
          <a href="/tambah" class="btn btn-primary mt-10">Tambah Data Obat Herbal</a>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\MidWeb_Obat_Nuuran\resources\views/index.blade.php ENDPATH**/ ?>