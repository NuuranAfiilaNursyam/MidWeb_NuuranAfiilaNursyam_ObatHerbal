<style>
    body { 
background: linear-gradient(124deg, #ff2400, #e81d1d, #e8b71d, #e3e81d, #1de840, #1ddde8, #2b1de8, #dd00f3, #dd00f3);
background-size: 1800% 1800%;
background:color: 1800;

-webkit-Idobat: rainbow 18s ease infinite;
-z-animation: rainbow 18s ease infinite;
-o-animation: rainbow 18s ease infinite;
  animation: rainbow 18s ease infinite;}

@-webkit-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@-moz-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@-o-keyframes rainbow {
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
@keyframes rainbow { 
    0%{background-position:0% 82%}
    50%{background-position:100% 19%}
    100%{background-position:0% 82%}
}
  </style>
  <!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lihat Data Obat - Obatan Herbal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <h2 class="text-center mt-2">Lihat Data Obat - Obatan Herbal</h2>
    <div class="container mt-3">
        <form>
        <div class="mb-3">
                <label for="Obat" class="form-label">Id Obat</label>
                <input type="text" class="form-control" id="Obat" name="Obat" value="<?php echo e($obatHerbal->Obat); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="Nama" class="form-label">Nama Obat</label>
                <input type="text" class="form-control" id="Nama" name="Nama" value="<?php echo e($obatHerbal->Nama); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="Bahan" class="form-label">Bahan Obat</label>
                <input type="text" class="form-control" id="Bahan" name="Bahan" value="<?php echo e($obatHerbal->Bahan); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="Khasiat" class="form-label">Khasiat Obat</label>
                <input type="text" class="form-control" id="Khasiat" name="Khasiat" value="<?php echo e($obatHerbal->Khasiat); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="Efek" class="form-label">Efek Samping</label>
                <input type="text" class="form-control" id="Efek" name="Efek" value="<?php echo e($obatHerbal->Efek); ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="Harga" class="form-label">Harga</label>
                <input type="text" class="form-control" id="Harga" name="Harga" value="<?php echo e($obatHerbal->Harga); ?>" disabled>
            </div>
            <a href="/" class="btn btn-danger">Kembali</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\MidWeb_Obat_Nuuran\resources\views/lihat.blade.php ENDPATH**/ ?>