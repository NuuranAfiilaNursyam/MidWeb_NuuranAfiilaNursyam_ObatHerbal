<?php

use App\Http\Controllers\ObatHerbalController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ObatHerbalController::class, 'index']);
Route::get('/tambah', [ObatHerbalController::class, 'tambah']);
Route::post('/tambah', [ObatHerbalController::class, 'store']);
Route::get('/hapus/{id}', [ObatHerbalController::class, 'hapus']);
Route::get('/edit/{id}', [ObatHerbalController::class, 'edit']);
Route::post('/edit/{id}', [ObatHerbalController::class, 'update']);
Route::get('/lihat/{id}', [ObatHerbalController::class, 'lihat']);