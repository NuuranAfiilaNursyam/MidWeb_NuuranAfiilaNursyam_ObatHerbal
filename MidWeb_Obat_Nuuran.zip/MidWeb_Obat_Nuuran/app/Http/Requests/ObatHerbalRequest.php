<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ObatHerbalRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(){
        $obatHerbalId = $this->route('id');

        return [
            'obat' => 'required|unique:obat_herbals,obat,'.$obatHerbalId,
            'nama' => 'required',
            'bahan' => 'required',
            'khasiat' => 'required',
            'efek' => 'required',
            'harga' => 'required',
        ];
    }

    public function messages()
    {
        return[
            'obat.unique' => 'Sudah ada Id Obat yang sama',
            'nama.required' => 'Nama Obat Herbal tidak boleh kosong',
            'bahan.required' => 'Bahan Obat Herbal tidak boleh kosong',
            'khasiat.required' => 'Khasiat Obat Herbal tidak boleh kosong',
            'efek.required' => 'Efek Samping tidak boleh kosong',
            'harga.required' => 'Harga tidak boleh kosong',
        ];
    }
}
