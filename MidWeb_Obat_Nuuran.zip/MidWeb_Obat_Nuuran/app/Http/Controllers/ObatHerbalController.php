<?php

namespace App\Http\Controllers;

use App\Models\ObatHerbal;
use Illuminate\Http\Request;
use App\Http\Requests\ObatHerbalRequest;

class ObatHerbalController extends Controller
{
    public function index(){
        $obatHerbal = ObatHerbal::get();
        return view('index', compact('obatHerbal'));
    }

    public function tambah(){
        return view('tambah');
    }

    public function edit($id){
        $obatHerbal = ObatHerbal::where('id', $id)->first();
        return view('edit', compact('obatHerbal'));
    }

    public function lihat($id){
        $obatHerbal = ObatHerbal::where('id', $id)->first();
        return view('lihat', compact('obatHerbal'));
    }

    public function store(ObatHerbalRequest $request)
    {
        $obatHerbal = new ObatHerbal();

        $obatHerbal->obat = $request->obat;
        $obatHerbal->nama = $request->nama;
        $obatHerbal->bahan = $request->bahan;
        $obatHerbal->khasiat = $request->khasiat;
        $obatHerbal->efek = $request->efek;
        $obatHerbal->harga = $request->harga;


        $obatHerbal->save();

        return redirect('/');
    }

    public function update(ObatHerbalRequest $request, $id)
    {
        $obatHerbal = ObatHerbal::where('id', $id)->first();

        $obatHerbal->obat = $request->obat;
        $obatHerbal->nama = $request->nama;
        $obatHerbal->bahan = $request->bahan;
        $obatHerbal->khasiat = $request->khasiat;
        $obatHerbal->efek = $request->efek;
        $obatHerbal->harga = $request->harga;
        
        $obatHerbal->update();

        return redirect('/');
    }

    public function hapus($id)
    {
        $obatHerbal = ObatHerbal::where('id', $id)->first();

        $obatHerbal->delete();

        return redirect('/');
    }
}
